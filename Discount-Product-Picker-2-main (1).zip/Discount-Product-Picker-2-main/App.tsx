
import React from 'react';
import ChatInterface from './components/ChatInterface';

function App() {
  return (
    <div className="bg-gray-900 text-white font-sans antialiased">
      <ChatInterface />
    </div>
  );
}

export default App;

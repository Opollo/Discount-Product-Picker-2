export enum MessageRole {
  USER = 'user',
  MODEL = 'model',
}

export interface Attachment {
  name: string;
  type: string;
}

export interface Message {
  id: string;
  role: MessageRole;
  text: string;
  attachment?: Attachment;
}

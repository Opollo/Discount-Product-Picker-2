import React, { useState, useRef } from 'react';
import SendIcon from './icons/SendIcon';
import PaperclipIcon from './icons/PaperclipIcon';
import MicrophoneIcon from './icons/MicrophoneIcon';
import StopIcon from './icons/StopIcon';

interface ChatInputProps {
    onSendMessage: (message: string, file?: { name: string; type: string; data: string }) => void;
    onAudioSubmit: (audioBlob: Blob) => void;
    isLoading: boolean;
    evidencePromptText: string | null;
}

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB
const SUPPORTED_FILE_TYPES = [
  'image/jpeg',
  'image/png',
  'application/pdf',
  'text/plain',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
];


const fileToDataUrl = (file: File): Promise<{ name: string; type: string; data: string; }> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
            const result = reader.result as string;
            resolve({
                name: file.name,
                type: file.type,
                data: result.split(',')[1], // Return only the base64 part
            });
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
};

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, onAudioSubmit, isLoading, evidencePromptText }) => {
    const [text, setText] = useState('');
    const [file, setFile] = useState<File | null>(null);
    const [uploadError, setUploadError] = useState<string | null>(null);
    const [isRecording, setIsRecording] = useState(false);
    
    const fileInputRef = useRef<HTMLInputElement>(null);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);

    const handleAttachClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setUploadError(null);
        if (e.target.files && e.target.files[0]) {
            const selectedFile = e.target.files[0];

            if (selectedFile.size > MAX_FILE_SIZE) {
                setUploadError(`File is too large. Maximum size is ${MAX_FILE_SIZE / 1024 / 1024}MB.`);
                setFile(null);
                if(fileInputRef.current) fileInputRef.current.value = "";
                return;
            }

            if (!SUPPORTED_FILE_TYPES.includes(selectedFile.type)) {
                setUploadError('Unsupported file type. Please upload images, PDFs, or text documents.');
                setFile(null);
                if(fileInputRef.current) fileInputRef.current.value = "";
                return;
            }

            setFile(selectedFile);
        }
    };
    
    const handleRemoveFile = () => {
        setFile(null);
        setUploadError(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    }

    const handleStartRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            setIsRecording(true);
            mediaRecorderRef.current = new MediaRecorder(stream, { mimeType: 'audio/webm' });
            mediaRecorderRef.current.addEventListener("dataavailable", (event) => {
                audioChunksRef.current.push(event.data);
            });
            mediaRecorderRef.current.addEventListener("stop", () => {
                const audioBlob = new Blob(audioChunksRef.current, {type: 'audio/webm'});
                onAudioSubmit(audioBlob);
                audioChunksRef.current = [];
                // Stop all tracks to release microphone
                stream.getTracks().forEach(track => track.stop());
            });
            mediaRecorderRef.current.start();
        } catch (err) {
            console.error("Error accessing microphone:", err);
            alert("Could not access the microphone. Please ensure you have given the necessary permissions.");
            setIsRecording(false);
        }
    };
    
    const handleStopRecording = () => {
        if (mediaRecorderRef.current) {
            mediaRecorderRef.current.stop();
            setIsRecording(false);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if ((!text.trim() && !file) || isLoading) return;

        let fileData;
        if (file) {
            fileData = await fileToDataUrl(file);
        }
        
        onSendMessage(text, fileData);
        setText('');
        setFile(null);
        setUploadError(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    return (
        <div className="bg-gray-800 p-2 rounded-xl flex flex-col gap-2">
            {uploadError && (
                 <div className="px-3 py-2 text-sm text-red-300 bg-red-900/40 border border-red-500/50 rounded-lg">
                    <p className="font-bold">Upload Failed</p>
                    <p>{uploadError}</p>
                </div>
            )}
            {file && (
                 <div className="px-3 py-1 text-sm text-gray-200 bg-gray-700/80 rounded-md flex justify-between items-center">
                    <span className="truncate">Attached: {file.name}</span>
                    <button onClick={handleRemoveFile} className="text-gray-400 hover:text-white">&times;</button>
                </div>
            )}
            <form onSubmit={handleSubmit} className="flex items-center gap-2">
                 <input
                    ref={fileInputRef}
                    type="file"
                    onChange={handleFileChange}
                    className="hidden"
                 />
                 <div className="relative group">
                    <button
                        type="button"
                        onClick={handleAttachClick}
                        disabled={isLoading}
                        className="text-gray-400 hover:text-white p-2 rounded-full hover:bg-gray-700 transition-colors disabled:opacity-50"
                        aria-label="Attach file"
                    >
                        <PaperclipIcon />
                    </button>
                    {evidencePromptText && (
                         <div className="absolute bottom-full mb-2 w-max max-w-xs bg-gray-900 text-white text-xs rounded-md py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                            {evidencePromptText}
                         </div>
                    )}
                 </div>
                 <button
                    type="button"
                    onClick={isRecording ? handleStopRecording : handleStartRecording}
                    disabled={isLoading}
                    className={`p-2 rounded-full transition-colors disabled:opacity-50 ${isRecording ? 'bg-red-500 text-white animate-pulse' : 'text-gray-400 hover:text-white hover:bg-gray-700'}`}
                    aria-label={isRecording ? 'Stop recording' : 'Start recording'}
                >
                    {isRecording ? <StopIcon /> : <MicrophoneIcon />}
                </button>

                <input
                    type="text"
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Type or record your message..."
                    disabled={isLoading}
                    className="flex-1 bg-transparent border-none text-gray-200 placeholder-gray-500 focus:ring-0 focus:outline-none disabled:opacity-50 px-2"
                />
                <button
                    type="submit"
                    disabled={isLoading || (!text.trim() && !file)}
                    className="bg-yellow-600 text-white p-2 rounded-lg hover:bg-yellow-700 disabled:bg-yellow-800/50 disabled:cursor-not-allowed transition-colors"
                    aria-label="Send message"
                >
                    <SendIcon />
                </button>
            </form>
        </div>
    );
};

export default ChatInput;
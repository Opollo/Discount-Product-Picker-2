import React from 'react';

const BotIcon: React.FC = () => (
    <div className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center p-1">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 120" fill="none">
            <path d="M50 0L10 20V65C10 95.1 26.3 115.5 50 120c23.7-4.5 40-24.9 40-55V20L50 0z" fill="#111827"/>
            <path d="M50 0L10 20V65C10 95.1 26.3 115.5 50 120c23.7-4.5 40-24.9 40-55V20L50 0z" stroke="#F7B32B" strokeWidth="3"/>
            <path d="M10 30 C 30 35, 70 35, 90 30" stroke="#4299E1" strokeWidth="6"/>
            <path d="M10 42 C 30 47, 70 47, 90 42" stroke="#FFFFFF" strokeWidth="6"/>
             <circle cx="50" cy="65" r="12" fill="#F7B32B"/>
        </svg>
    </div>
);

export default BotIcon;

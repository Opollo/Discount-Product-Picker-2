import React from 'react';

const CoatOfArmsIcon: React.FC = () => (
  <img 
    src="https://upload.wikimedia.org/wikipedia/commons/7/7c/Coat_of_arms_of_Uganda.svg" 
    alt="Coat of Arms of Uganda" 
    className="h-24 w-auto"
  />
);

export default CoatOfArmsIcon;

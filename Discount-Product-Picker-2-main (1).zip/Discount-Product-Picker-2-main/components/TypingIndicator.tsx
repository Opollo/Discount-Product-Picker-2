
import React from 'react';
import BotIcon from './icons/BotIcon';

const TypingIndicator: React.FC = () => {
    return (
        <div className="flex items-start gap-3">
            <div className="w-8 h-8 flex-shrink-0">
                <BotIcon />
            </div>
            <div className="bg-gray-800 rounded-r-xl rounded-bl-xl p-4 flex items-center space-x-1.5">
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse [animation-delay:-0.3s]"></div>
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse [animation-delay:-0.15s]"></div>
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse"></div>
            </div>
        </div>
    );
};

export default TypingIndicator;

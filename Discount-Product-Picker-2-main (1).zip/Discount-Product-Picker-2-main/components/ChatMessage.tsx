import React from 'react';
import { Message, MessageRole } from '../types';
import BotIcon from './icons/BotIcon';
import UserIcon from './icons/UserIcon';
import PaperclipIcon from './icons/PaperclipIcon';

interface ChatMessageProps {
    message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
    const isModel = message.role === MessageRole.MODEL;

    const wrapperClasses = isModel
        ? 'flex items-start gap-3'
        : 'flex items-start gap-3 flex-row-reverse';

    const bubbleClasses = isModel
        ? 'bg-gray-800 text-gray-200 rounded-r-xl rounded-bl-xl'
        : 'bg-yellow-600 text-white rounded-l-xl rounded-br-xl';

    const icon = isModel ? <BotIcon /> : <UserIcon />;
    
    // Simple markdown for bold, italics, and newlines
    const renderText = (text: string) => {
        const parts = text.split(/(\*\*.*?\*\*|\*.*?\*|\n)/g);
        return parts.map((part, index) => {
            if (part.startsWith('**') && part.endsWith('**')) {
                return <strong key={index}>{part.slice(2, -2)}</strong>;
            }
            if (part.startsWith('*') && part.endsWith('*')) {
                return <em key={index}>{part.slice(1, -1)}</em>;
            }
            if (part === '\n') {
                return <br key={index} />;
            }
            return part;
        });
    };

    return (
        <div className={wrapperClasses}>
            <div className="w-8 h-8 flex-shrink-0">{icon}</div>
            <div className={`p-4 max-w-md md:max-w-lg break-words ${bubbleClasses}`}>
                <div>{renderText(message.text)}</div>
                {message.attachment && (
                    <div className="mt-2 bg-gray-700/50 rounded-lg p-2 flex items-center gap-2 text-sm text-gray-300 border border-gray-600">
                        <PaperclipIcon className="w-4 h-4 flex-shrink-0" />
                        <span className="truncate">{message.attachment.name}</span>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ChatMessage;

import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { Message, MessageRole, Attachment } from '../types';
import ChatMessage from './ChatMessage';
import ChatInput from './ChatInput';
import TypingIndicator from './TypingIndicator';
import CoatOfArmsIcon from './icons/CoatOfArmsIcon';
import SpeakerOnIcon from './icons/SpeakerOnIcon';
import SpeakerOffIcon from './icons/SpeakerOffIcon';
import WhatsAppIcon from './icons/WhatsAppIcon';


const SYSTEM_INSTRUCTION = `You are an expert AI assistant for the Kole District Local Government's grievance system. Your name is 'Kole Guide'. Kole District is located in Northern Uganda, part of the Lango Sub-region, and has about 4000 employees. Your primary role is to guide these employees through the grievance reporting process based on the Uganda Government standing orders.

**Input Handling:**
- **File Uploads:** If the user uploads a file, you MUST acknowledge it by saying \`I have received your file: [filename]. I will analyze its content along with your message.\` Then, proceed with the analysis.
- **Voice Input:** The user can provide input via voice, which will be transcribed to text. Treat the transcribed text as if the user typed it directly.

**Reference Documents:** You have been provided with two key documents:
1.  The "Uganda Government Standing Orders."
2.  The "Job Descriptions and Specifications for Jobs in Local Governments, 2011" (which includes roles, responsibilities, and reporting structures for positions like Chief Administrative Officer, Personnel Officer, Medical Officer, etc.).

**Conversation Flow:**

**Step 1: Introduction**
When a conversation starts, you MUST introduce yourself and your purpose clearly. Your first message is predefined, so you will continue from there.

**Step 2: Acknowledge Job Title and Inquire About Grievance**
After the user provides their title or position, you MUST acknowledge it and then directly ask how you can assist. Respond with: **"Thank you for confirming your position. How can I help you today?"** Then, wait for the user to describe their grievance.

**Step 3: Grievance Categorization**
Once the employee describes their grievance, your next step is to help them categorize it. Based on their description, you will recognize the issue and suggest one or more of the following predefined categories:
- **Working Conditions**: Issues related to the physical work environment, safety, or resources.
- **Harassment**: Incidents of bullying, intimidation, or unwelcome conduct.
- **Unfair Treatment**: Concerns about discrimination, favoritism, or biased decisions.
- **Compensation or Salary**: Disputes related to pay, allowances, or other benefits.
- **Job Description**: Issues regarding duties, responsibilities, or scope of work.
- **Performance Appraisal**: Concerns about the fairness or accuracy of a performance review.

**Important Note on Job Roles and Supervision:**
Even though you are not proactively asking about job roles or the supervisory chain, you MUST use the 'Job Descriptions' document if the user's grievance is related to their duties or if they ask who their supervisor is. For instance:
- If a user's grievance is "I'm being asked to do tasks not in my job description," you should then use the document to provide their official 'Key Functions' and ask them to compare.
- If a user asks "Who should I report this to?", you must use the "Reports to" field to trace their supervisory chain and present it as a numbered list, from immediate supervisor to the top, explaining each role as previously instructed.

**Step 4: Providing Official Guidance and Gathering Evidence**
After the employee confirms a category, you MUST first provide a direct reference to the relevant section of the Uganda Government Standing Orders. Then, to trigger the evidence prompt in the UI, you will start your next question with a special marker. **This is a strict instruction.**

Use the following mapping for references and evidence questions. The marker MUST be at the beginning of your response.
- **Working Conditions**: Refer to Uganda Government Standing Orders, Section A-n, "Occupational Safety and Health." Then ask: **"[EVIDENCE_PROMPT:Working Conditions]To help build your report, could you provide details about the unsafe conditions? For example, please describe the specific hazard, its location, and how long it has been an issue. Have you reported it before?"**
- **Harassment**: Refer to Uganda Government Standing Orders, Section A-b, "Code of Conduct and Ethics," subsection on Harassment. Then ask: **"[EVIDENCE_PROMPT:Harassment]I understand this is difficult. To proceed, it's helpful to document specific details. Could you provide the dates and times of the incidents, the names of anyone involved, and any witnesses?"**
- **Unfair Treatment**: Refer to Uganda Government Standing Orders, Section A-c, "Appointments, Promotions, and Staff Relations," subsection on Disciplinary Procedures. Then ask: **"[EVIDENCE_PROMPT:Unfair Treatment]To properly document your case, can you provide specific dates, times, and names of individuals involved? It would also be helpful to note if there were any witnesses or written communications (like emails) related to this."**
- **Compensation or Salary**: Refer to Uganda Government Standing Orders, Section B, "Salaries and Allowances." Then ask: **"[EVIDENCE_PROMPT:Compensation or Salary]For compensation-related grievances, it's important to have clear documentation. Can you provide any relevant documents, such as your appointment letter, payslips, or official communication regarding your salary and allowances?"**
- **Job Description**: Refer to Uganda Government Standing Orders, Section A-a, "Management of the Public Service." Then ask: **"[EVIDENCE_PROMPT:Job Description]To clarify the discrepancy, could you point out which specific duties are not aligning with your official job description? Please provide examples of tasks you are being asked to perform that fall outside your documented responsibilities."**
- **Performance Appraisal**: Refer to Uganda Government Standing Orders, Section A-e, "Staff Performance Appraisal." First, explain the process using the details from PS FORM 5. Then, ask the clarifying question: **"Was your grievance related to the setting of targets, the final rating, or the opportunity to provide comments?"** After they respond, follow up with the evidence question: **"[EVIDENCE_PROMPT:Performance Appraisal]Thank you for clarifying. To support your grievance, please gather a copy of your appraisal form, any documentation of your achievements that were not considered, and notes from your appraisal meeting."**

**Step 5: Summarize the Grievance for Review**
After the user has responded to the evidence-gathering questions, your final task is to provide a concise summary of the information they've shared. You MUST structure the summary clearly like this:

**Grievance Summary**
*   **Category:** [The category the user confirmed, e.g., Unfair Treatment]
*   **Key Details:** [Briefly summarize the user's initial description of the incident.]
*   **Evidence to Include:** [List the types of evidence the user has mentioned or that you prompted them to gather, e.g., "Dates, times, and names of individuals involved," "Relevant emails or written communication," "Names of any witnesses."]

After presenting the summary, you MUST ask for confirmation: **"Please review this summary. Does it accurately capture the main points of your grievance before you proceed with the formal process?"**

**Step 6: Final Action**
Once the user confirms the summary, provide a concluding statement that includes a special action marker for the UI. **This is a strict instruction.** Your response must be: **"Thank you for confirming. You can now use this summary to formally document your grievance. [ACTION:FINALIZE_GRIEVANCE]"** This concludes your guidance.

**General Instructions:**
Your tone must be professional, empathetic, and helpful at all times. Do not provide legal advice, but strictly guide them on the official, established process. Be patient and supportive.`;

const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64data = reader.result as string;
      // remove the data url prefix
      resolve(base64data.split(',')[1]);
    };
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(blob);
  });
};

const evidencePrompts: Record<string, string> = {
    'Working Conditions': 'e.g., photos of the hazard, maintenance requests.',
    'Harassment': 'e.g., screenshots of messages, witness statements.',
    'Unfair Treatment': 'e.g., emails, letters, or official documents.',
    'Compensation or Salary': 'e.g., payslips, appointment letter, bank statements.',
    'Job Description': 'e.g., your official job description, a list of assigned tasks.',
    'Performance Appraisal': 'e.g., your appraisal form, performance records.',
};

const ChatInterface: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [isTranscribing, setIsTranscribing] = useState<boolean>(false);
    const [isTtsEnabled, setIsTtsEnabled] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [evidencePromptText, setEvidencePromptText] = useState<string | null>(null);
    const [finalSummary, setFinalSummary] = useState<string | null>(null);
    const chatRef = useRef<Chat | null>(null);
    const aiRef = useRef<GoogleGenAI | null>(null);
    const messagesEndRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        try {
            if (!process.env.API_KEY) {
                throw new Error("API key not found. Please ensure the API_KEY environment variable is set.");
            }
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            aiRef.current = ai;
            const chat = ai.chats.create({
                model: 'gemini-2.5-flash',
                config: {
                    systemInstruction: SYSTEM_INSTRUCTION,
                },
            });
            chatRef.current = chat;
            setMessages([
                {
                    id: crypto.randomUUID(),
                    role: MessageRole.MODEL,
                    text: "Welcome to the Kole District Grievance Guidance System. I am Kole Guide, your AI assistant. To help you effectively, please tell me your official title or position."
                }
            ]);
        } catch (e) {
            setError((e as Error).message);
            console.error(e);
        }
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isLoading, isTranscribing]);

    useEffect(() => {
        if (!isTtsEnabled || !('speechSynthesis' in window)) return;
    
        const lastMessage = messages[messages.length - 1];
        if (lastMessage && lastMessage.role === MessageRole.MODEL) {
            window.speechSynthesis.cancel();
            
            const utterance = new SpeechSynthesisUtterance(lastMessage.text);
            window.speechSynthesis.speak(utterance);
        }
    }, [messages, isTtsEnabled]);

    const toggleTts = () => {
        setIsTtsEnabled(prevState => {
            const newState = !prevState;
            if (!newState) {
                window.speechSynthesis.cancel();
            }
            return newState;
        });
    };

    const handleSendMessage = async (
        text: string,
        file?: { name: string; type: string; data: string }
    ) => {
        if (!text.trim() && !file) return;
        window.speechSynthesis.cancel();
        setEvidencePromptText(null);
        setFinalSummary(null);

        const attachment: Attachment | undefined = file
            ? { name: file.name, type: file.type }
            : undefined;

        const userMessage: Message = {
            id: crypto.randomUUID(),
            role: MessageRole.USER,
            text,
            attachment,
        };
        setMessages(prevMessages => [...prevMessages, userMessage]);
        setIsLoading(true);
        setError(null);

        try {
            if (!chatRef.current) {
                throw new Error("Chat session not initialized.");
            }
            
            const messageParts: (string | { inlineData: { mimeType: string; data: string; } })[] = [text];
            if (file) {
                 messageParts.push({
                    inlineData: {
                        mimeType: file.type,
                        data: file.data
                    }
                });
            }

            const response = await chatRef.current.sendMessage({ message: messageParts });
            let responseText = response.text;
            
            // Check for evidence prompt marker
            const evidenceMatch = responseText.match(/^\[EVIDENCE_PROMPT:(.+)\]/);
            if (evidenceMatch) {
                const category = evidenceMatch[1];
                setEvidencePromptText(evidencePrompts[category] || null);
                responseText = responseText.replace(/^\[EVIDENCE_PROMPT:.+\]/, '').trim();
            }

            // Check for finalization marker
            if (responseText.includes('[ACTION:FINALIZE_GRIEVANCE]')) {
                 const summaryMessage = messages[messages.length-1];
                 // a bit of a hack: the summary is the message *before* the user confirms. Let's find it.
                 // find last message from model that starts with **Grievance Summary**
                 const lastSummary = [...messages, userMessage].reverse().find(m => m.role === MessageRole.MODEL && m.text.startsWith('**Grievance Summary**'));
                 if (lastSummary) {
                     setFinalSummary(lastSummary.text);
                 }
                 responseText = responseText.replace('[ACTION:FINALIZE_GRIEVANCE]', '').trim();
            }

            const modelResponse: Message = {
                id: crypto.randomUUID(),
                role: MessageRole.MODEL,
                text: responseText,
            };
            setMessages(prevMessages => [...prevMessages, modelResponse]);
        } catch (e) {
            const errorMessage = "Sorry, I encountered an error. Please try again later.";
            setError(errorMessage);
            setMessages(prevMessages => [...prevMessages, {
                id: crypto.randomUUID(),
                role: MessageRole.MODEL,
                text: errorMessage
            }]);
            console.error(e);
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleAudioSubmit = async (audioBlob: Blob) => {
        setIsTranscribing(true);
        setError(null);
        try {
            if (!aiRef.current) {
                throw new Error("AI Client not initialized.");
            }
            const base64Audio = await blobToBase64(audioBlob);
            const response: GenerateContentResponse = await aiRef.current.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: {
                    parts: [
                        { text: "Transcribe this audio recording precisely and concisely." },
                        { inlineData: { mimeType: audioBlob.type, data: base64Audio } }
                    ]
                },
            });
            const transcribedText = response.text;
            if (transcribedText) {
                await handleSendMessage(transcribedText);
            } else {
                throw new Error("Transcription failed. The response was empty.");
            }
        } catch(e) {
             const errorMessage = "Sorry, I couldn't understand the audio. Please try again.";
             setError(errorMessage);
             console.error(e);
        } finally {
            setIsTranscribing(false);
        }
    }
    
    const handleShareOnWhatsApp = () => {
        if (!finalSummary) return;
        const districtNumber = "256782724971";
        const message = encodeURIComponent(finalSummary);
        const whatsappUrl = `https://wa.me/${districtNumber}?text=${message}`;
        window.open(whatsappUrl, '_blank');
    };

    return (
        <div className="flex flex-col h-screen max-w-3xl mx-auto p-4 bg-gray-900 text-gray-100 font-sans">
             <header className="text-center py-4 border-b border-gray-700 flex flex-col items-center gap-4 relative">
                <div className="absolute top-4 right-4">
                    <button
                        onClick={toggleTts}
                        className="p-2 rounded-full text-gray-400 hover:text-white hover:bg-gray-700 transition-colors"
                        aria-label={isTtsEnabled ? "Disable text-to-speech" : "Enable text-to-speech"}
                    >
                        {isTtsEnabled ? <SpeakerOnIcon /> : <SpeakerOffIcon />}
                    </button>
                </div>
                <CoatOfArmsIcon />
                <h1 className="text-2xl font-bold text-gray-100">Kole District Grievance System</h1>
                <p className="text-sm text-gray-400">Your confidential AI assistant for grievance procedures</p>
            </header>

            <main className="flex-1 overflow-y-auto p-4 space-y-6">
                {messages.map((message) => (
                    <ChatMessage key={message.id} message={message} />
                ))}
                {isLoading && <TypingIndicator />}
                {isTranscribing && <div className="text-center text-sm text-gray-400">Transcribing audio...</div>}
                <div ref={messagesEndRef} />
            </main>
            
            {finalSummary && (
                <div className="p-4 flex justify-center">
                    <button
                        onClick={handleShareOnWhatsApp}
                        className="flex items-center gap-2 bg-green-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-700 transition-colors"
                    >
                        <WhatsAppIcon />
                        Share Summary on WhatsApp
                    </button>
                </div>
            )}

            {error && (
                <div className="p-2 text-center text-red-400 text-sm">
                    <p>{error}</p>
                </div>
            )}

            <footer className="py-4">
                <ChatInput 
                    onSendMessage={handleSendMessage} 
                    onAudioSubmit={handleAudioSubmit}
                    isLoading={isLoading || isTranscribing} 
                    evidencePromptText={evidencePromptText}
                />
            </footer>
        </div>
    );
};

export default ChatInterface;